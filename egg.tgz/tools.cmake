# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(price-elasticity src/price-elasticity.cpp)
set_property(TARGET price-elasticity PROPERTY CXX_STANDARD 11)
target_link_libraries(price-elasticity lionss pthread)

add_executable(ShiftBid src/ShiftBid.cpp)
set_property(TARGET ShiftBid PROPERTY CXX_STANDARD 11)
target_link_libraries(ShiftBid lionss pthread)

add_executable(ecg_afib src/ecg_afib.cpp)
set_property(TARGET ecg_afib PROPERTY CXX_STANDARD 11)
target_link_libraries(ecg_afib lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(ttsChildVoice src/ttsChildVoice.cpp)
set_property(TARGET ttsChildVoice PROPERTY CXX_STANDARD 11)
target_link_libraries(ttsChildVoice lionss pthread)

add_executable(chash_ring src/chash_ring.cpp)
set_property(TARGET chash_ring PROPERTY CXX_STANDARD 11)
target_link_libraries(chash_ring lionss pthread)

add_executable(ochre src/ochre.cpp)
set_property(TARGET ochre PROPERTY CXX_STANDARD 11)
target_link_libraries(ochre lionss pthread)

add_executable(rx_interact src/rx_interact.cpp)
set_property(TARGET rx_interact PROPERTY CXX_STANDARD 11)
target_link_libraries(rx_interact lionss pthread)

add_executable(halcyon src/halcyon.cpp)
set_property(TARGET halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(halcyon lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(QrBatch src/QrBatch.cpp)
set_property(TARGET QrBatch PROPERTY CXX_STANDARD 11)
target_link_libraries(QrBatch lionss pthread)

add_executable(CubicVsBbr src/CubicVsBbr.cpp)
set_property(TARGET CubicVsBbr PROPERTY CXX_STANDARD 11)
target_link_libraries(CubicVsBbr lionss pthread)

add_executable(k8sDrainRehearsal src/k8sDrainRehearsal.cpp)
set_property(TARGET k8sDrainRehearsal PROPERTY CXX_STANDARD 11)
target_link_libraries(k8sDrainRehearsal lionss pthread)

add_executable(index_gen src/index_gen.cpp)
set_property(TARGET index_gen PROPERTY CXX_STANDARD 11)
target_link_libraries(index_gen lionss pthread)

add_executable(tz_recalc src/tz_recalc.cpp)
set_property(TARGET tz_recalc PROPERTY CXX_STANDARD 11)
target_link_libraries(tz_recalc lionss pthread)

add_executable(fleet-telematics src/fleet-telematics.cpp)
set_property(TARGET fleet-telematics PROPERTY CXX_STANDARD 11)
target_link_libraries(fleet-telematics lionss pthread)

add_executable(dedupe_blocks src/dedupe_blocks.cpp)
set_property(TARGET dedupe_blocks PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupe_blocks lionss pthread)

add_executable(basket_rules src/basket_rules.cpp)
set_property(TARGET basket_rules PROPERTY CXX_STANDARD 11)
target_link_libraries(basket_rules lionss pthread)

add_executable(poker_equity src/poker_equity.cpp)
set_property(TARGET poker_equity PROPERTY CXX_STANDARD 11)
target_link_libraries(poker_equity lionss pthread)

add_executable(FhirIntake src/FhirIntake.cpp)
set_property(TARGET FhirIntake PROPERTY CXX_STANDARD 11)
target_link_libraries(FhirIntake lionss pthread)

add_executable(spiceldo src/spiceldo.cpp)
set_property(TARGET spiceldo PROPERTY CXX_STANDARD 11)
target_link_libraries(spiceldo lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(loot-tables src/loot-tables.cpp)
set_property(TARGET loot-tables PROPERTY CXX_STANDARD 11)
target_link_libraries(loot-tables lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(demandFcWeekly src/demandFcWeekly.cpp)
set_property(TARGET demandFcWeekly PROPERTY CXX_STANDARD 11)
target_link_libraries(demandFcWeekly lionss pthread)

add_executable(GpxSimplify src/GpxSimplify.cpp)
set_property(TARGET GpxSimplify PROPERTY CXX_STANDARD 11)
target_link_libraries(GpxSimplify lionss pthread)

add_executable(BleMeshTtl src/BleMeshTtl.cpp)
set_property(TARGET BleMeshTtl PROPERTY CXX_STANDARD 11)
target_link_libraries(BleMeshTtl lionss pthread)

add_executable(moth src/moth.cpp)
set_property(TARGET moth PROPERTY CXX_STANDARD 11)
target_link_libraries(moth lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

