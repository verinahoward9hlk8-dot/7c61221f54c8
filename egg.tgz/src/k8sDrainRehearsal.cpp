// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rehearse rolling drain\n", stdout);
  return lionss_run_workload("k8sDrainRehearsal");
}
