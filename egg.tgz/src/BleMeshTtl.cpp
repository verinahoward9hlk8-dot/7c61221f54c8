// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flood with TTL 7"); }
int main(){
  announce();
  return lionss_run_workload("BleMeshTtl");
}
