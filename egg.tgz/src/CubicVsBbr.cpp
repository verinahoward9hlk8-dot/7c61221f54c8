// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("60-s flow comparison"); }
int main(){
  announce();
  return lionss_run_workload("CubicVsBbr");
}
