// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Authorization-code flow with PKCE\n", stdout);
  return lionss_run_workload("ochre");
}
