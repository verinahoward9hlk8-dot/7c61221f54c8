// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Transient 0-2 ms"); }
int main(){
  announce();
  return lionss_run_workload("spiceldo");
}
