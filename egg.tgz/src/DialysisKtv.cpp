// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute Kt/V and URR"); }
int main(){
  announce();
  return lionss_run_workload("DialysisKtv");
}
