// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Greedy-mesh loaded chunks\n", stdout);
  return lionss_run_workload("voxelforge");
}
