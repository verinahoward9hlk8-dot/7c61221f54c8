// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("AF detection from RR irregularity"); }
int main(){
  announce();
  return lionss_run_workload("ecg_afib");
}
