// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Detect harsh braking events\n", stdout);
  return lionss_run_workload("fleet-telematics");
}
