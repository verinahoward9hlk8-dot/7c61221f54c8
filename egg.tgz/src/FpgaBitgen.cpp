// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Place, route, bitstream"); }
int main(){
  announce();
  return lionss_run_workload("FpgaBitgen");
}
