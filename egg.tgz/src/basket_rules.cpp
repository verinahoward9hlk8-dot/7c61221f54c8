// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("FP-growth, support 0.3"); }
int main(){
  announce();
  return lionss_run_workload("basket_rules");
}
