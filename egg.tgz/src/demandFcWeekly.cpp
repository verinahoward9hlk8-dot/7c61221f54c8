// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("13-week forecast, ETS\n", stdout);
  return lionss_run_workload("demandFcWeekly");
}
