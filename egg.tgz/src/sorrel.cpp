// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tumbling 5-min counts\n", stdout);
  return lionss_run_workload("sorrel");
}
